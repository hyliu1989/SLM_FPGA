#include <stdio.h>
#include <stddef.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include "system.h"
#include "sys/alt_dma.h"
#include "sys/alt_alarm.h"
#include "sys/alt_cache.h"

#include "sys/alt_dev.h"
#include "priv/alt_file.h"
#include "alt_types.h" 

// the dimensions of the graphics display
#define PIX_MAP_WIDTH 640
#define PIX_MAP_HEIGHT 480

// the dimensions for a software cursor
#define CURSOR_WIDTH 16
#define CURSOR_HEIGHT 16

// some common color values, based on RGB565
#define BLACK 0x0000
#define RED   0xf800
#define GREEN 0x07e0
#define BLUE  0x001f
#define WHITE 0xffff

#define READ_BUFFER_SIZE 64

// globally allocate 2 video frame buffers, a main and an alternate
unsigned short main_frame_buffer[PIX_MAP_WIDTH * PIX_MAP_HEIGHT];

// other miscellaneous storage
alt_dma_txchan tx_chan;   // tx dma channel descriptor
alt_dma_rxchan rx_chan;   // rx dma channel descriptor

// define the structure for the VGA ISR context pointer to use, (interupt service routine)
typedef struct {
  volatile unsigned long frame_buffer_base;  // all we need to know in the ISR is where the frame buffer is
} vga_dma_done_context;

// prototype definitions
void vga_dma_done(vga_dma_done_context *context);
void print_startup(void);
void clear_screen(void);
void paint_marker(void);

// the main entry point
int main(void)
{
  volatile vga_dma_done_context my_isr_context; // interupt service routine context storage
  int c;                                        // storage for STDIN character input
  int temp;
  unsigned short *uncached_buffer;
  unsigned char read_buffer[READ_BUFFER_SIZE];
  int read_cnt;
  int i;
  int next_pixel_offset;
  alt_u32 last_jtag_tick;
  int recent_jtag;
  int next_byte_hi_lo;
  short next_pixel;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned short *)(alt_remap_uncached( (void *)(main_frame_buffer), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
  
  // forgive me for this hack but I couldn't figure out a more eligant way to do this
  alt_fd_list[STDIN_FILENO].fd_flags |= O_NONBLOCK;
  
  // setup context for video dma isr
  my_isr_context.frame_buffer_base = (unsigned long)(main_frame_buffer);

  // Start the frame buffer DMA to get a video picture driving out the VGA channel
  
  // open the dma channel for transmitting
  tx_chan = alt_dma_txchan_open ("/dev/dma_0");
  if (tx_chan == NULL)
  {
    printf("DMA TX channel failed to open.\n\nExiting\n\n");
    return(-1);
  }
/*
  // open the dma channel for reception
  rx_chan = alt_dma_rxchan_open ("/dev/dma_0");
  if (rx_chan == NULL)
  {
    printf("DMA RX channel failed to open.\n\nExiting\n\n");
    return(-1);
  }
*/
  // set dma mode for 32-bit transfers
  temp = alt_dma_txchan_ioctl ( tx_chan,
                                ALT_DMA_SET_MODE_32,
                                NULL);
  if(temp < 0)
  {
    printf("Error configuring DMA channel - ALT_DMA_SET_MODE_32\n\n Exiting\n\n");
    return(-1);
  }
  // set dma mode for rx streaming
  temp = alt_dma_txchan_ioctl ( tx_chan,
                                ALT_DMA_RX_STREAM_ON,
                                (void *)(0x0));
  if(temp < 0)
  {
    printf("Error configuring DMA channel - ALT_DMA_RX_STREAM_ON\n\n Exiting\n\n");
    return(-1);
  }
  // queue the dma transfer to copy frame buffer
  temp = alt_dma_txchan_send (  tx_chan,
                                (const void*)(main_frame_buffer),
                                (( PIX_MAP_WIDTH * PIX_MAP_HEIGHT ) + PIX_MAP_WIDTH) * 2 * 2,
                                (alt_txchan_done *)(vga_dma_done),
                                (void*)(&my_isr_context));
  if(temp < 0)
  {
    printf("Error starting DMA channel\n\n Exiting\n\n");
    return(-1);
  }

  // clear the VGA display and print the menu out the STDOUT interface
  clear_screen();

  // print the menu display out stdout
  print_startup();

  // initialize the globals for image download
  next_pixel_offset = 0;
  next_byte_hi_lo = 1;
  next_pixel = 0;
  
  recent_jtag = 1;
  last_jtag_tick = alt_nticks();
  
  // flush any stale STDIN data
  while((c=getchar()) != -1);
  
  // this is the main continous loop for this program it continually polls for
  // input on STDIN
  while(1)
  {
    // read stdin
    read_cnt = read( STDIN_FILENO, read_buffer, READ_BUFFER_SIZE);
    
    if(read_cnt == -1)  // there was no data read
    {
      // clear this so the next while loop doesn't execute
      read_cnt = 0;
      
      // see if we're waiting for JTAG activity to timeout
      if(recent_jtag)
      {
        // after 5 seconds of no JTAG we reset the next_pixel_offset and paint the marker
        if(((alt_nticks()) - last_jtag_tick) >= (5 * (alt_ticks_per_second())))
        {
          paint_marker();
          next_pixel_offset = 0;
          recent_jtag = 0;
        }
      }
    }
    else    // there was data read
    {
      last_jtag_tick = alt_nticks();
      recent_jtag = 1;
    }
    
    // process the read buffer data
    i = 0;
    while(read_cnt)
    {
      if(next_byte_hi_lo) // high byte of short
      {
        next_pixel = (read_buffer[i] & 0xff) << 8;
        next_byte_hi_lo = 0;
      }
      else    // low byte of short
      {
        next_pixel |= (read_buffer[i] & 0xff);
        next_byte_hi_lo = 1;

        // write the pixel to the frame buffer
        *(uncached_buffer + (next_pixel_offset++)) = next_pixel;
        
        // wrap the pixel offset to the begining when we reach the end
        if(next_pixel_offset == (PIX_MAP_WIDTH * PIX_MAP_HEIGHT))
        {
          next_pixel_offset = 0;
        }
      }
      read_cnt--;
      i++;
    }
  }
  
  printf("End of Program reached.\n\nExiting\n\n");  // technically, we should never get here
  return(0);
}

void print_startup(void)    // this routine prints the menu out stdout
{
  printf("\n\nIMAGE DOWNLOAD DEMO STARTED\n\n");
  printf("\
This program is now waiting for binary image data to download thru the JTAG UART\n\
");
  fflush(stdout);
}

void clear_screen(void)    // this routine clears the main vga buffer RGB color gradients
{
  int i;
  unsigned short *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned short *)(alt_remap_uncached( (void *)(main_frame_buffer), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
  
  // fill the buffer with a red gradient
  for (i=0;i<PIX_MAP_WIDTH*PIX_MAP_HEIGHT;i++)
  {
    *(uncached_buffer + i) = RED - ((i%32)<<11);
  }

  // fill the buffer 2/3 with a green gradient
  for (i=0;i<PIX_MAP_WIDTH*PIX_MAP_HEIGHT*2/3;i++)
  {
    *(uncached_buffer + i) = GREEN - ((i%64)<<5);
  }

  // fill the buffer 1/3 with a blue gradient
  for (i=0;i<PIX_MAP_WIDTH*PIX_MAP_HEIGHT/3;i++)
  {
    *(uncached_buffer + i) = BLUE - ((i%32)<<0);
  }
}

void vga_dma_done(vga_dma_done_context *context)  // VGA DMA ISR
{
  // NOTE: calling alt_dma_txchan_send() at ISR time like we do here is not recommended
  // but since this is the only time we call this during normal execution, it's not likely
  // to cause any problems.  And since this demo doesn't use an OS, it's hard for us to
  // make this happen in a timely fashion any other way.

  // setup another dma to feed the frame buffer out the vga
  alt_dma_txchan_send ( tx_chan,
                        (const void*)(context->frame_buffer_base),
                        (PIX_MAP_WIDTH * PIX_MAP_HEIGHT) * 2,
                        (alt_txchan_done *)(vga_dma_done),
                        (void*)(context));
}

void paint_marker(void)    // this routine paints a multicolor marker on the bottom right of the screen
{
  int i;
  int end_of_line;
  unsigned short *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned short *)(alt_remap_uncached( (void *)(main_frame_buffer), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
  
  end_of_line = (PIX_MAP_WIDTH * PIX_MAP_HEIGHT) - 1;
  
  // draw a white line
  for (i=0;i<5;i++)
  {
    *(uncached_buffer + (end_of_line - i)) = WHITE;
  }

  end_of_line -= PIX_MAP_WIDTH;

  // draw a red line
  for (i=0;i<5;i++)
  {
    *(uncached_buffer + (end_of_line - i)) = RED;
  }

  end_of_line -= PIX_MAP_WIDTH;

  // draw a green line
  for (i=0;i<5;i++)
  {
    *(uncached_buffer + (end_of_line - i)) = GREEN;
  }

  end_of_line -= PIX_MAP_WIDTH;

  // draw a blue line
  for (i=0;i<5;i++)
  {
    *(uncached_buffer + (end_of_line - i)) = BLUE;
  }

  end_of_line -= PIX_MAP_WIDTH;

  // draw a black line
  for (i=0;i<5;i++)
  {
    *(uncached_buffer + (end_of_line - i)) = BLACK;
  }

}
