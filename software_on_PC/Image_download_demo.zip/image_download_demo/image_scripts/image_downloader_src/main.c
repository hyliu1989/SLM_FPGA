/* 
 * This program will take a binary input file and push it down to a JTAG UART in
 * an SOPC system.
 */

#include <stdio.h>
#include <time.h>
#include "my_jtag_atlantic.h"
#include "fcntl.h"

#define READ_BUF_SIZE 16384

int main(int argc, char *argv[])
{
  JTAGATLANTIC *link;
  int error;
  int result;
  const char *other_info;
  clock_t start_time, end_time;
  float total_time;
  char readbuf[READ_BUF_SIZE];
  size_t readcnt;
  FILE *in_fp;
  
  
  // do we have an input argument on the command line?
  if(argc != 2)
  {
    printf("Error - no input file found as command line argument\n");
    return -1;
  }
  
  // open the input file for reading in binary mode
  in_fp = fopen(argv[1], "rb");
  if(in_fp == NULL)
  {
    printf("Error - cannot open file \"%s\"\n", argv[1]);
    return -1;
  }
  
  printf("\nInput file \"%s\" successfully opened.\n\n", argv[1]);

  printf("Attempting to open JTAG link.\n\n");

  // open the JTAG Link
  if((link = jtagatlantic_open(NULL, 0x0, -1, NULL)))
  {
    printf("JTAG Link opened successfully, now downloading...\n\n");

    // time the download
    start_time = clock();
    
    // Read the input file
    while(((readcnt = fread(readbuf, 1, READ_BUF_SIZE, in_fp)) > 0))
    {
      // flush the JTAG Link output buffer
      result = jtagatlantic_flush(link);
      if(result != 0)
      {
        printf("\n\nError on JTAG Link flush\n\nExiting\n");
        return(-1);
      }
      
      // write data to JTAG Link
      result = jtagatlantic_write(link, readbuf, readcnt);
      if(result == -1)
      {
        printf("\n\nERROR DURING WRITE\n\n");
        error = jtagatlantic_get_error(&other_info);
        printf("error = %d\n\n", error);
        printf("Exiting\n");
        return (-1);
      }
      if(result != readcnt)
      {
        printf("\n\nWRITE COUNT NOT EQUAL TO READCNT, I'M GIVING UP\n\n");
        printf("Exiting\n");
        return (-1);
      }
    }

    // flush the JTAG Link output buffer
    result = jtagatlantic_flush(link);
    if(result != 0)
    {
      printf("\n\nError on JTAG Link flush\n\nExiting\n");
      return(-1);
    }

    // calculate the download time
    end_time = clock();
    total_time = (float)(end_time - start_time) / (float)(CLOCKS_PER_SEC);
    
    printf("File download complete.  %0.2f seconds\n\n", total_time);
    fclose(in_fp);
    return(0);
    
  }
  else    // if we couldn't open the JTAG Link
  {
    printf("\n\nFAILED TO OPEN CONNECTION\n\n");
    error = jtagatlantic_get_error(&other_info);
    printf("error = %d\n\n", error);    
    fclose(in_fp);
    printf("Exiting\n");
    return(-1);
  }
}
