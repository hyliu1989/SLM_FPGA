This is an example application that runs on a host PC and communicates to a JTAG UART
in a Nios SOPC system thru the jtag_atlantic.dll.  You can build the example by running
the ./build_script in a cygwin bash shell.  You should have cygwin installed along with
the C development environment.  The build_script is commented as well as all the related
files.