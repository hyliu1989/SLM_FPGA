#!/bin/perl
# file2c_mod.pl
#
#
# This sub-routine converts content of input file into an array in byte HEX format
# 
# The script takes 4 arguments
# arg 0 - input file
# arg 2 - variable name
#
#
# Usage example: "cat <input_file> | file2c.pl <C variable name> > <output_header_file>"

unless ( @ARGV >= 1) {
	die "$0: You must enter the variable name of your data!\n";
}

$var_name = $ARGV[0];
$var_name_array = $var_name."[]";

#open(INPUT, "$file") || die "Failed to open input file $file  Cannot convert!!!";

#
# Output the variable declaration and set an attribute on it.
#

print("#include <alt_types.h>\n\n");
print("const alt_u8 __attribute__ ((aligned(4))) $var_name_array = {\n");

$i = 0;
while(read(STDIN, $data, 1))
{
  if($i == 0)
    {
      print("\t");
    }
  #
  # Here's the magic...  use unpack to grab the file's data into an unsigned
  # char variable.
  #

  printf("%#02x, ", unpack("C", $data));

  $i++;
  if($i == 10)
    {
      print("\n");
      $i = 0;
    }
}

print("};\n\n");
