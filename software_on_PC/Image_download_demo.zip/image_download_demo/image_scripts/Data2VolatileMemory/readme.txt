================================================================================
DESCRIPTION                                                                     
================================================================================
The included Perl script (file2c.pl) "converts" STDIN into a C char array
(directed to STDOUT), that can be used to store any sort of data in volatile 
memory.

********************************************************************************
NOTE:  This was written for use by a Nios II processor, the data type for the 
array is specific to this processor (alt_u8).  However, it should be simple to 
convert this script such that it can be used to generate a C char array for any 
processor or to another data type, altogether.
********************************************************************************

Also included, with this script is some C code written for a Nios II processor.

Though this example uses a this text file, it treats the data just as it would 
binary data, so the process would be identical for any incoming data format.

================================================================================
LIST OF FILES
================================================================================
readme.txt  - This file.
	    - Describes content and provides input to the file2c.pl script.
file2c.pl   - Converts any file into a C char array.
PrintData.c - Sample code for a Nios II processor.

================================================================================
REQUIREMENTS
================================================================================
Command line environment to run the script.
	- Any Cygwin installation or UNIX shell prompt, that includes Perl.
	NOTE:  The Nios II SDK Shell qualifies.

================================================================================
HOW TO GENERATE YOUR C HEADER
================================================================================
The usage for the script is included in the script's comments, and duplicated
here:

cat <input_file> | ./file2c.pl <variable name> > <C_header_file>

For example, to generate the header file for PrintData.c, you would do the 
following:

cat readme.txt | ./file2c.pl in_text > data.h

...submitting this in hopes that it is found useful.
