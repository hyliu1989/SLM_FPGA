/*
 * PrintData example.  This code prints every character in the
 * in_text[] array to STDOUT.
 * 
 * This array can contain anything, but the intent of this code
 * is to test the file2c.pl script.  Therefore, the in_text[] 
 * array should be populated with the contents of the readme.txt file
 * (also included with this distribution).
 *
 */

#include <stdio.h>
#include "data.h"

int main()
{
  int i;
  
  printf( "Below you should see the input text from the readme.txt file.\n\n");
  
  i = 0; /* Initialize the array iterator. */
  
  while( in_text[i] )
  {
    printf( "%c", (char) in_text[i] );
    ++i; /* Increment to the next character in the array. */
  }

  return 0;
}
