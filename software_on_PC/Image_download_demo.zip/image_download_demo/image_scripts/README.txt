To use this demo on a Nios II 1C20 Cyclone Development board, power the board up with a Lancelot VGA adapter mounted on the Santa Cruz headers and attach a USB Blaster to the JTAG header.  Then launch a BASH shell and change to this directory, image_scripts.  From here you can use the following commands:

At this point your board has just been powered up, and we have no idea what it's doing.

To download the SOF configuration image to the board use this command:

nios-sof

At this point your board should be running the SOF hardware image that we just downloaded, but it has no software application to run, not the one we want anyway.

To download the software application image to the board use this command:

nios2-download -g ../software/image_download_demo/Debug/image_download_demo.elf

At this point your board should be running the software application on the hardware design that we just downloaded to the board.  You should see red, green, and blue gradient bars on the screen.

To download a picture to display on the screen, use this command.

./jtag_image_downloader.exe testbmp.BMP.tmp

At this point you should see the image that we just downloaded to the board over the JTAG UART.

Here are the utilities that are provided in this directory:

- convert_bmp24_big_endian.pl -- this is a perl script that can take a 24 bit per pixel BMP image with 640x480 dimensions and extract the image data to a new file, storing the pixels in the RGB565 16-bit format that this demo requires.  The output of this script is big endian, which is suitable for direct download to the demo using the jtag_image_downloader.exe utility.

- convert_bmp24_little_endian.pl -- this is a perl script that can take a 24 bit per pixel BMP image with 640x480 dimensions and extract the image data to a new file, storing the pixels in the RGB565 16-bit format that this demo requires.  The output of this script is little endian, which is suitable for creating image data that can be included in the software application itself by using the file2c.pl script.

- jtag_image_downloader.exe -- this is an applicatoin that takes a binary image file that has been processed for use on the demo with convert_bmp24_big_endian.pl, and it downloads it to the board over the JTAG UART connection.

- file2c.pl -- this is a script that takes a binary file and outputs text for a C header file so the binary data can be included into a C program.

- testbmp.BMP -- this is a 24 bit per pixel BMP image of a colorful lego dinosaur

- testbmp.BMP.tmp -- this is the testbmp.BMP image after being processed by convert_bmp24_big_endian.pl, so it is now ready to download to the demo.
